export class Game {
  title : string;
  publisher : string;
  price : number;

  constructor(
   title : string,
   publisher : string,
   price : number
  ) { 
    this.title = title;
    this.publisher = publisher;
    this.price = price;
  }
}